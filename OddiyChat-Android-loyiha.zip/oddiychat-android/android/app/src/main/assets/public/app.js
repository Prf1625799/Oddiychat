'use strict';
/* Oddiy Chat — serversiz mesh (P2P) video konferensiya. PeerJS + WebRTC.
   Xabar turlari eski Windows (OddiyChat.exe) bilan mos: peers / new-peer / chat.
   Yangilari (hello / state / admin-mute / admin-allow) eski dastur tomonidan e'tiborsiz qoldiriladi. */

const MAX_PEERS = 10;
const $ = (id) => document.getElementById(id);

// ---------- Holat ----------
let peer = null;
let myNick = '';
let roomName = '';
let isAdmin = false;
let inRoom = false;
let localStream = null;
let facing = 'user';
let wakeLock = null;
let placeholderTimer = null;
let audioCtx = null;
let unread = 0;
let reconnectTimer = null;

const me = { mic: true, cam: true, hand: false, forceMuted: false, hasMic: false, hasCam: false };

const dataConns = new Map();   // id -> DataConnection (eng so'nggisi)
const mediaConns = new Map();  // id -> Set<MediaConnection>
const knownPeers = new Set();  // xonadagi (mendan boshqa) hamma id lar
const peerState = new Map();   // id -> {mic, cam, hand, muted}
let pendingConns = [];         // xonaga kirishdan oldin kelgan ulanishlar
let pendingCalls = [];

// ---------- Yordamchilar ----------
function setStatus(text, kind) {
  const el = $('status');
  el.textContent = text;
  el.className = kind || '';
}
let toastTimer = null;
function toast(text, ms = 3000) {
  const t = $('toast');
  t.textContent = text;
  t.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => (t.hidden = true), ms);
}
function sanitizeNick(s) {
  return s.trim().replace(/[^a-zA-Z0-9_-]+/g, '_').replace(/[_-]{2,}/g, '_').replace(/^[_-]+|[_-]+$/g, '');
}
function isWide() { return window.matchMedia('(min-width:900px) and (orientation:landscape)').matches; }
function chatOpen() { return isWide() || !$('chat').classList.contains('closed'); }
function ls(k, v) { try { if (v === undefined) return localStorage.getItem(k) || ''; localStorage.setItem(k, v); } catch (e) { return ''; } }

function addMessage(text, kind, who) {
  const div = document.createElement('div');
  div.className = 'msg ' + kind;
  if (who) {
    const w = document.createElement('span');
    w.className = 'who';
    w.textContent = who;
    div.appendChild(w);
  }
  div.appendChild(document.createTextNode(text));
  const box = $('messages');
  const atBottom = box.scrollHeight - box.scrollTop - box.clientHeight < 80;
  box.appendChild(div);
  if (atBottom || kind === 'me') box.scrollTop = box.scrollHeight;
}
const addSystem = (t) => addMessage(t, 'sys');

// ---------- Mahalliy media ----------
function makePlaceholder(kind) {
  // Kamera/mikrofon bo'lmaganda ham boshqalarni ko'rish/eshitish uchun bo'sh trek kerak.
  try {
    if (kind === 'video') {
      const c = document.createElement('canvas');
      c.width = 320; c.height = 240;
      const g = c.getContext('2d');
      const draw = () => { g.fillStyle = '#1b2740'; g.fillRect(0, 0, 320, 240); };
      draw();
      placeholderTimer = setInterval(draw, 700);
      const t = c.captureStream(2).getVideoTracks()[0];
      t.enabled = false;
      return t;
    }
    audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
    const dest = audioCtx.createMediaStreamDestination();
    const t = dest.stream.getAudioTracks()[0];
    t.enabled = false;
    return t;
  } catch (e) { return null; }
}

async function acquireMedia() {
  const audio = { echoCancellation: true, noiseSuppression: true, autoGainControl: true };
  const video = { facingMode: 'user', width: { ideal: 640 }, height: { ideal: 480 }, frameRate: { ideal: 24, max: 30 } };
  const attempts = [{ audio, video }, { audio, video: false }, { audio: false, video }];
  for (const c of attempts) {
    try { return await navigator.mediaDevices.getUserMedia(c); } catch (e) { /* keyingisi */ }
  }
  return null;
}

async function prepareLocalStream() {
  const real = navigator.mediaDevices ? await acquireMedia() : null;
  const stream = new MediaStream();
  const a = real && real.getAudioTracks()[0];
  const v = real && real.getVideoTracks()[0];
  me.hasMic = !!a; me.hasCam = !!v;
  me.mic = !!a; me.cam = !!v;
  const at = a || makePlaceholder('audio');
  const vt = v || makePlaceholder('video');
  if (at) stream.addTrack(at);
  if (vt) stream.addTrack(vt);
  localStream = stream;
  if (!real) addSystem('Kamera/mikrofonga ruxsat berilmadi. Faqat matn orqali qatnashasiz (boshqalarni ko\'rib-eshitasiz).');
  else if (!a) addSystem('Mikrofon topilmadi yoki ruxsat berilmadi.');
  else if (!v) addSystem('Kamera topilmadi yoki ruxsat berilmadi.');
  let multi = false;
  try { multi = (await navigator.mediaDevices.enumerateDevices()).filter((d) => d.kind === 'videoinput').length > 1; } catch (e) {}
  $('flipBtn').hidden = !(me.hasCam && multi);
}

function stopLocalMedia() {
  if (localStream) localStream.getTracks().forEach((t) => t.stop());
  localStream = null;
  clearInterval(placeholderTimer);
  placeholderTimer = null;
}

function senderVideoAll() {
  const out = [];
  for (const set of mediaConns.values()) for (const call of set) {
    const pc = call.peerConnection;
    if (pc) pc.getSenders().forEach((s) => out.push(s));
  }
  return out;
}

async function swapTrack(kind, newTrack) {
  const old = localStream.getTracks().find((t) => t.kind === kind);
  if (old) { localStream.removeTrack(old); old.stop(); }
  newTrack.enabled = kind === 'audio' ? me.mic : me.cam;
  localStream.addTrack(newTrack);
  for (const s of senderVideoAll()) {
    if (!s.track || s.track.kind === kind) { try { await s.replaceTrack(newTrack); } catch (e) {} }
  }
  const v = ($('tile-' + myNick) && $('tile-' + myNick).querySelector('video'));
  if (v) v.srcObject = localStream;
}

async function flipCamera() {
  if (!me.hasCam) return;
  const next = facing === 'user' ? 'environment' : 'user';
  let s = null;
  const base = { width: { ideal: 640 }, height: { ideal: 480 }, frameRate: { ideal: 24, max: 30 } };
  try { s = await navigator.mediaDevices.getUserMedia({ video: { ...base, facingMode: { exact: next } } }); }
  catch (e) {
    try { s = await navigator.mediaDevices.getUserMedia({ video: { ...base, facingMode: next } }); } catch (e2) {}
  }
  if (!s) { toast('Kamerani almashtirib bo\'lmadi'); return; }
  facing = next;
  await swapTrack('video', s.getVideoTracks()[0]);
  const tile = $('tile-' + myNick);
  if (tile) tile.classList.toggle('back', facing === 'environment');
}

// Ilova fonga o'tib qaytganda Android kamerani to'xtatadi — tiklaymiz
async function recoverTracks() {
  if (!inRoom || !localStream) return;
  try {
    for (const kind of ['audio', 'video']) {
      const has = kind === 'audio' ? me.hasMic : me.hasCam;
      const t = localStream.getTracks().find((x) => x.kind === kind);
      if (has && t && t.readyState === 'ended') {
        const s = await navigator.mediaDevices.getUserMedia(kind === 'audio'
          ? { audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true } }
          : { video: { facingMode: facing, width: { ideal: 640 }, height: { ideal: 480 } } });
        await swapTrack(kind, s.getTracks()[0]);
      }
    }
  } catch (e) { toast('Kamera/mikrofonni tiklab bo\'lmadi. Xonadan chiqib qayta kiring.'); }
}

async function keepAwake() {
  try { if ('wakeLock' in navigator) wakeLock = await navigator.wakeLock.request('screen'); } catch (e) {}
}
function releaseAwake() { try { wakeLock && wakeLock.release(); } catch (e) {} wakeLock = null; }

// ---------- Video plitkalar ----------
function ensureTile(id, isLocal) {
  let tile = $('tile-' + id);
  if (tile) return tile;
  tile = document.createElement('div');
  tile.className = 'tile nocam' + (isLocal ? ' local' : '');
  tile.id = 'tile-' + id;
  const video = document.createElement('video');
  video.autoplay = true;
  video.playsInline = true;
  video.setAttribute('playsinline', '');
  if (isLocal) video.muted = true;
  const avatar = document.createElement('div');
  avatar.className = 'avatar';
  const sp = document.createElement('span');
  sp.textContent = id.charAt(0);
  avatar.appendChild(sp);
  const flags = document.createElement('div');
  flags.className = 'flags';
  const admin = document.createElement('div');
  admin.className = 'admin';
  const label = document.createElement('div');
  label.className = 'label';
  const b = document.createElement('b');
  label.appendChild(b);
  tile.append(video, avatar, flags, admin, label);
  $('videos').appendChild(tile);
  layoutVideos();
  refreshTile(id);
  return tile;
}

function removeTile(id) {
  const el = $('tile-' + id);
  if (el) el.remove();
  layoutVideos();
}

function layoutVideos() {
  const n = $('videos').children.length;
  $('videos').dataset.n = String(Math.min(n, 5));
  $('videos').classList.toggle('many', n > 4);
}

function setRemoteStream(id, stream) {
  const tile = ensureTile(id, false);
  const v = tile.querySelector('video');
  if (v.srcObject !== stream) v.srcObject = stream;
  v.play().catch(() => {});
  refreshTile(id);
}

function refreshTile(id) {
  const tile = $('tile-' + id);
  if (!tile) return;
  const isLocal = id === myNick;
  const st = isLocal ? { mic: me.mic, cam: me.cam, hand: me.hand, muted: me.forceMuted } : (peerState.get(id) || {});
  const camOn = isLocal ? me.cam : (st.cam !== false && hasLiveVideo(tile));
  tile.classList.toggle('nocam', !camOn);
  tile.classList.toggle('hand', !!st.hand);

  const name = id + (id === roomName ? ' 👑' : '') + (isLocal ? ' (siz)' : '');
  tile.querySelector('.label b').textContent = name;

  const flags = tile.querySelector('.flags');
  flags.textContent = '';
  const addFlag = (t, c) => { const s = document.createElement('span'); s.className = 'flag ' + (c || ''); s.textContent = t; flags.appendChild(s); };
  if (st.hand) addFlag('✋ Qo\'l ko\'tardi', 'hand');
  if (st.muted) addFlag('🔇 Rahbar o\'chirgan');
  else if (st.mic === false) addFlag('🔇');

  const admin = tile.querySelector('.admin');
  admin.textContent = '';
  if (isAdmin && !isLocal) {
    if (st.hand || st.muted) {
      const al = document.createElement('button');
      al.className = 'allow';
      al.textContent = st.hand ? '✋ Ruxsat berish' : '🔊 Ruxsat berish';
      al.onclick = () => adminAllow(id);
      admin.appendChild(al);
    }
    if (!st.muted) {
      const mu = document.createElement('button');
      mu.textContent = '🔇 O\'chirish';
      mu.onclick = () => adminMute(id);
      admin.appendChild(mu);
    }
  }
}
function hasLiveVideo(tile) {
  const s = tile.querySelector('video').srcObject;
  return !!s && s.getVideoTracks().length > 0;
}
function refreshAllTiles() { for (const el of $('videos').children) refreshTile(el.id.slice(5)); }

// ---------- Ulanishlar ----------
const myState = () => ({ mic: me.mic, cam: me.cam, hand: me.hand, muted: me.forceMuted });
function broadcast(obj, exclude) {
  for (const [id, c] of dataConns) if (id !== exclude && c.open) { try { c.send(obj); } catch (e) {} }
}
function sendState() { broadcast({ type: 'state', ...myState() }); refreshTile(myNick); }

function connectData(id) {
  if (!peer || id === myNick || dataConns.has(id)) return;
  setupData(peer.connect(id, { reliable: true }), true);
}
// Ikki tomon bir vaqtda ulanmasligi uchun: faqat id si "kichik" tomon boshlaydi
const shouldInitiate = (id) => myNick < id;

function callPeer(id) {
  if (!peer || !localStream || id === myNick) return;
  trackCall(peer.call(id, localStream));
}
function trackCall(call) {
  const id = call.peer;
  if (!mediaConns.has(id)) mediaConns.set(id, new Set());
  mediaConns.get(id).add(call);
  call.on('stream', (s) => { setRemoteStream(id, s); applyBitrate(); });
  const done = () => {
    const set = mediaConns.get(id);
    if (set) { set.delete(call); if (!set.size) mediaConns.delete(id); }
  };
  call.on('close', done);
  call.on('error', done);
}

function applyBitrate() {
  const n = knownPeers.size + 1;
  const kbps = n <= 2 ? 900 : n <= 4 ? 450 : n <= 6 ? 250 : 150;
  for (const s of senderVideoAll()) {
    if (!s.track || s.track.kind !== 'video') continue;
    try {
      const p = s.getParameters();
      if (!p.encodings || !p.encodings.length) p.encodings = [{}];
      p.encodings[0].maxBitrate = kbps * 1000;
      s.setParameters(p).catch(() => {});
    } catch (e) {}
  }
}

function setupData(conn, outgoing) {
  const id = conn.peer;
  dataConns.set(id, conn);
  knownPeers.add(id);
  ensureTile(id, false);

  const onOpen = () => {
    dataConns.set(id, conn);
    conn.send({ type: 'hello', room: roomName, ...myState() });
    conn.send({ type: 'peers', list: [...knownPeers].filter((x) => x !== id) });
    broadcast({ type: 'new-peer', id }, id);
    if (outgoing) callPeer(id);
    updateCount();
  };
  if (conn.open) onOpen(); else conn.on('open', onOpen);

  conn.on('data', (data) => {
    if (!data || typeof data !== 'object') return;
    switch (data.type) {
      case 'peers':
        if (Array.isArray(data.list)) for (const x of data.list) learnPeer(x);
        break;
      case 'new-peer':
        learnPeer(data.id);
        break;
      case 'chat': {
        const text = String(data.text || '').slice(0, 1000);
        if (!text) break;
        addMessage(text, 'them', id);
        if (!chatOpen()) { unread++; updateUnread(); }
        break;
      }
      case 'hello':
      case 'state': {
        const prev = peerState.get(id) || {};
        const st = { mic: data.mic !== false, cam: data.cam !== false, hand: !!data.hand, muted: !!data.muted };
        peerState.set(id, st);
        if (st.hand && !prev.hand && isAdmin) {
          toast('✋ ' + id + ' qo\'l ko\'tardi');
          try { navigator.vibrate && navigator.vibrate(120); } catch (e) {}
        }
        refreshTile(id);
        break;
      }
      case 'admin-mute':
        // Faqat xona rahbaridan qabul qilinadi
        if (!isAdmin && id === roomName) forceMute();
        break;
      case 'admin-allow':
        if (!isAdmin && id === roomName) {
          me.forceMuted = false;
          me.hand = false;
          toast('Rahbar sizga gapirishga ruxsat berdi. Mikrofonni yoqishingiz mumkin.');
          updateControls();
          sendState();
        }
        break;
    }
  });

  conn.on('close', () => {
    if (dataConns.get(id) !== conn) return;  // eskirgan dublikat
    dataConns.delete(id);
    knownPeers.delete(id);
    peerState.delete(id);
    const set = mediaConns.get(id);
    if (set) { for (const c of [...set]) { try { c.close(); } catch (e) {} } mediaConns.delete(id); }
    removeTile(id);
    addSystem(`"${id}" xonadan chiqdi.`);
    updateCount();
  });
  conn.on('error', () => {});
}

function learnPeer(id) {
  if (!id || typeof id !== 'string' || id === myNick) return;
  knownPeers.add(id);
  ensureTile(id, false);
  if (!dataConns.has(id) && shouldInitiate(id)) connectData(id);
  updateCount();
}

function updateCount() {
  const n = knownPeers.size + 1;
  $('countInfo').textContent = n + ' kishi' + (n > MAX_PEERS ? ' — ko\'p, sifat pasayishi mumkin' : '');
  applyBitrate();
}

// ---------- Rahbar funksiyalari ----------
function adminMute(id) {
  const c = dataConns.get(id);
  if (c && c.open) c.send({ type: 'admin-mute' });
  const st = peerState.get(id) || {};
  peerState.set(id, { ...st, mic: false, muted: true });
  refreshTile(id);
}
function adminAllow(id) {
  const c = dataConns.get(id);
  if (c && c.open) c.send({ type: 'admin-allow' });
  const st = peerState.get(id) || {};
  peerState.set(id, { ...st, muted: false, hand: false });
  refreshTile(id);
}
function forceMute() {
  me.forceMuted = true;
  me.mic = false;
  if (localStream) localStream.getAudioTracks().forEach((t) => (t.enabled = false));
  toast('Rahbar mikrofoningizni o\'chirdi. Gapirish uchun "Qo\'l" tugmasini bosing.', 4500);
  updateControls();
  sendState();
}

// ---------- Boshqaruv tugmalari ----------
function updateControls() {
  const mic = $('micBtn'), cam = $('camBtn'), hand = $('handBtn');
  mic.classList.toggle('off', !me.mic);
  mic.querySelector('.ic').textContent = me.mic ? '🎤' : '🔇';
  mic.querySelector('.tx').textContent = me.forceMuted ? 'Bloklangan' : me.hasMic ? (me.mic ? 'Mikrofon' : 'Yoqish') : 'Yo\'q';
  mic.disabled = !me.hasMic;
  cam.classList.toggle('off', !me.cam);
  cam.querySelector('.tx').textContent = me.hasCam ? (me.cam ? 'Kamera' : 'Yoqish') : 'Yo\'q';
  cam.disabled = !me.hasCam;
  hand.classList.toggle('on', me.hand);
  hand.querySelector('.tx').textContent = me.hand ? 'Tushirish' : 'Qo\'l';
  hand.hidden = isAdmin;
}
function updateUnread() {
  const u = $('unread');
  u.hidden = unread === 0;
  u.textContent = unread > 99 ? '99+' : String(unread);
}
function openChat(open) {
  $('chat').classList.toggle('closed', !open);
  if (open) { unread = 0; updateUnread(); const m = $('messages'); m.scrollTop = m.scrollHeight; }
}

$('micBtn').onclick = () => {
  if (!me.hasMic) return;
  if (me.forceMuted) { toast('Rahbar mikrofoningizni o\'chirgan. "Qo\'l" tugmasi orqali ruxsat so\'rang.'); return; }
  me.mic = !me.mic;
  localStream.getAudioTracks().forEach((t) => (t.enabled = me.mic));
  updateControls(); sendState();
};
$('camBtn').onclick = () => {
  if (!me.hasCam) return;
  me.cam = !me.cam;
  localStream.getVideoTracks().forEach((t) => (t.enabled = me.cam));
  updateControls(); sendState();
};
$('flipBtn').onclick = flipCamera;
$('handBtn').onclick = () => {
  me.hand = !me.hand;
  updateControls(); sendState();
  toast(me.hand ? 'Qo\'l ko\'tarildi — rahbarga ko\'rsatildi' : 'Qo\'l tushirildi', 1800);
};
$('chatBtn').onclick = () => openChat($('chat').classList.contains('closed'));
$('chatClose').onclick = () => openChat(false);
$('muteAllBtn').onclick = () => {
  if (!confirm('Barcha ishtirokchilarning mikrofonini o\'chiraymi?')) return;
  for (const id of dataConns.keys()) adminMute(id);
};
$('leaveBtn').onclick = () => { if (confirm('Xonadan chiqasizmi?')) leaveRoom(); };

function sendChat() {
  const text = $('msgInput').value.trim();
  if (!text) return;
  addMessage(text, 'me');
  broadcast({ type: 'chat', from: myNick, text });
  $('msgInput').value = '';
}
$('sendBtn').onclick = sendChat;
$('msgInput').addEventListener('keydown', (e) => { if (e.key === 'Enter') sendChat(); });

// ---------- Ro'yxatdan o'tish ----------
function peerOptions() {
  const o = { debug: 1 };
  const host = ls('oddiy_srv_host').trim();
  if (host) {
    o.host = host;
    o.port = parseInt(ls('oddiy_srv_port'), 10) || 443;
    o.path = ls('oddiy_srv_path') || '/';
    o.secure = true;
  }
  return o;
}

function register() {
  const nick = sanitizeNick($('myNick').value);
  if (!nick) { setStatus('Iltimos, nickname kiriting (lotin harf, raqam, _ yoki -).', 'err'); return; }
  if (nick.length < 2) { setStatus('Nickname kamida 2 belgi bo\'lsin.', 'err'); return; }
  myNick = nick;
  $('myNick').value = nick;
  ls('oddiy_nick', nick);
  ls('oddiy_srv_host', $('srvHost').value.trim());
  ls('oddiy_srv_port', $('srvPort').value.trim());
  ls('oddiy_srv_path', $('srvPath').value.trim());
  $('registerBtn').disabled = true;
  $('myNick').disabled = true;
  setStatus('Ulanmoqda...', '');

  try { peer = new Peer(myNick, peerOptions()); }
  catch (e) { setStatus('Ulanib bo\'lmadi: ' + e.message, 'err'); unlockRegister(); return; }

  peer.on('open', (id) => {
    clearTimeout(reconnectTimer);
    setStatus('Faol. Nickname: ' + id, 'ok');
    $('step1').hidden = true;
    $('step2').hidden = false;
    if (!$('roomNick').value) $('roomNick').value = ls('oddiy_room');
  });
  peer.on('connection', (conn) => { if (inRoom) setupData(conn, false); else pendingConns.push(conn); });
  peer.on('call', (call) => {
    if (inRoom && localStream) { call.answer(localStream); trackCall(call); }
    else pendingCalls.push(call);
  });
  peer.on('error', (err) => {
    switch (err.type) {
      case 'unavailable-id': setStatus('Bu nickname band. Boshqasini tanlang.', 'err'); unlockRegister(); break;
      case 'invalid-id': setStatus('Nickname noto\'g\'ri. Faqat lotin harf, raqam, _ va -.', 'err'); unlockRegister(); break;
      case 'peer-unavailable':
        addSystem('Bunday xona/nickname topilmadi yoki hali onlayn emas.');
        toast('Xona topilmadi yoki xona egasi hali onlayn emas', 4000);
        break;
      case 'network': case 'server-error': case 'socket-error': case 'socket-closed':
        if (!inRoom && $('step2').hidden) { setStatus('Internetga ulanib bo\'lmadi. Aloqani tekshirib, qayta urinib ko\'ring.', 'err'); unlockRegister(); }
        else toast('Aloqa muammosi: ' + err.type, 3500);
        break;
      default: setStatus('Xatolik: ' + err.type, 'err');
    }
  });
  peer.on('disconnected', () => {
    if (peer.destroyed) return;
    toast('Internetdan uzildi. Qayta ulanilmoqda...', 3000);
    clearTimeout(reconnectTimer);
    reconnectTimer = setTimeout(() => { try { peer.reconnect(); } catch (e) {} }, 2000);
  });
}
function unlockRegister() {
  $('registerBtn').disabled = false;
  $('myNick').disabled = false;
  try { peer && peer.destroy(); } catch (e) {}
  peer = null;
}
$('registerBtn').onclick = register;
$('myNick').addEventListener('keydown', (e) => { if (e.key === 'Enter') register(); });
$('roomNick').addEventListener('keydown', (e) => { if (e.key === 'Enter') $('joinBtn').click(); });
$('srvReset').onclick = () => { ['host', 'port', 'path'].forEach((k) => { ls('oddiy_srv_' + k, ''); $('srv' + k[0].toUpperCase() + k.slice(1)).value = ''; }); toast('Standart server tiklandi'); };

// ---------- Xonaga kirish / chiqish ----------
$('joinBtn').onclick = async () => {
  const target = sanitizeNick($('roomNick').value);
  if (!target) { setStatus('Xona nomini kiriting.', 'err'); return; }
  $('joinBtn').disabled = true;
  setStatus('Kamera va mikrofon tayyorlanmoqda...', '');

  roomName = target;
  isAdmin = target === myNick;
  ls('oddiy_room', target);
  me.hand = false; me.forceMuted = false;

  await prepareLocalStream();
  inRoom = true;

  $('setup').hidden = true;
  $('room').hidden = false;
  $('roomTitle').textContent = 'Xona: ' + roomName;
  $('roleBadge').hidden = !isAdmin;
  $('muteAllBtn').hidden = !isAdmin;
  $('messages').textContent = '';
  openChat(false);

  const tile = ensureTile(myNick, true);
  tile.querySelector('video').srcObject = localStream;
  tile.classList.toggle('back', false);
  facing = 'user';
  refreshTile(myNick);
  updateControls();
  keepAwake();

  addSystem(`Xonaga qo'shildingiz: ${roomName}`);
  if (isAdmin) addSystem('Siz xona rahbarisiz. Boshqalar xona nomi sifatida sizning nickname\'ingizni kiritib qo\'shiladi. Rahbar sifatida ishtirokchi mikrofonini o\'chira olasiz.');
  else connectData(roomName);

  // Kutib turgan ulanish va qo'ng'iroqlar
  for (const c of pendingConns.splice(0)) setupData(c, false);
  for (const call of pendingCalls.splice(0)) { call.answer(localStream); trackCall(call); }
  updateCount();
  $('joinBtn').disabled = false;
  setStatus('Faol. Nickname: ' + myNick, 'ok');
};

function leaveRoom() {
  inRoom = false;
  for (const c of dataConns.values()) { try { c.close(); } catch (e) {} }
  for (const set of mediaConns.values()) for (const c of set) { try { c.close(); } catch (e) {} }
  dataConns.clear(); mediaConns.clear(); knownPeers.clear(); peerState.clear();
  pendingConns.forEach((c) => { try { c.close(); } catch (e) {} });
  pendingConns = []; pendingCalls = [];
  stopLocalMedia();
  releaseAwake();
  $('videos').textContent = '';
  $('messages').textContent = '';
  me.hand = false; me.forceMuted = false;
  isAdmin = false; roomName = '';
  $('room').hidden = true;
  $('setup').hidden = false;
  setStatus('Xonadan chiqdingiz. Yangi xonaga kirishingiz mumkin.', '');
}

// ---------- Tizim hodisalari ----------
document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'visible' && inRoom) { keepAwake(); recoverTracks(); }
});
window.addEventListener('online', () => { if (peer && peer.disconnected && !peer.destroyed) { try { peer.reconnect(); } catch (e) {} } });
window.addEventListener('resize', () => { if (isWide()) { unread = 0; updateUnread(); } });

// Android "Orqaga" tugmasi (Capacitor)
try {
  const App = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.App;
  if (App) App.addListener('backButton', () => {
    if (inRoom && !$('chat').classList.contains('closed') && !isWide()) openChat(false);
    else if (inRoom) $('leaveBtn').click();
    else App.exitApp();
  });
} catch (e) {}

// ---------- Boshlang'ich ----------
(function init() {
  $('myNick').value = ls('oddiy_nick');
  $('srvHost').value = ls('oddiy_srv_host');
  $('srvPort').value = ls('oddiy_srv_port');
  $('srvPath').value = ls('oddiy_srv_path');
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    setStatus('Bu qurilmada kamera/mikrofon ishlamaydi. Faqat matn rejimi.', 'err');
  }
})();
