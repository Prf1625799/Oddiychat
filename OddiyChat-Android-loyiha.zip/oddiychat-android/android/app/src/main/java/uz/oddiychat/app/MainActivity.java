package uz.oddiychat.app;

import android.content.Context;
import android.media.AudioManager;
import android.os.Bundle;
import android.view.WindowManager;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    private AudioManager audio;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Konferensiya paytida ekran o'chib qolmasin
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        audio = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
    }

    @Override
    public void onResume() {
        super.onResume();
        // Ovoz karnaydan chiqsin, exo bekor qilish (AEC) to'g'ri ishlasin
        if (audio != null) {
            audio.setMode(AudioManager.MODE_IN_COMMUNICATION);
            audio.setSpeakerphoneOn(true);
        }
    }

    @Override
    public void onDestroy() {
        if (audio != null) {
            audio.setSpeakerphoneOn(false);
            audio.setMode(AudioManager.MODE_NORMAL);
        }
        super.onDestroy();
    }
}
