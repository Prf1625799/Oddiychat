# Oddiy Chat — Android

Serversiz (P2P) video konferensiya + matnli chat. Windows dasturi (OddiyChat.exe) bilan bir xil nickname/xona tizimi,
shuning uchun telefon va kompyuter bitta xonada gaplasha oladi.

## Imkoniyatlar
- Video konferensiya (mesh, 10 kishigacha) va matnli chat
- Xona rahbari (xona nomi = rahbarning nickname'i): ishtirokchi mikrofonini o'chirish, hammasini o'chirish
- O'chirilgan ishtirokchi "Qo'l" tugmasi bilan so'raydi; rahbar plitkada ✋ belgisi va "Ruxsat berish" tugmasini ko'radi
- Old/orqa kamerani almashtirish, ekran o'chmaydi, ovoz karnaydan chiqadi
- Kamera/mikrofon bo'lmasa ham qatnashish (ko'rish-eshitish + chat)
- Ilova fonga o'tib qaytganda kamera/mikrofon tiklanadi
- Internet uzilsa avtomatik qayta ulanadi

## APK olish — 1-usul: GitHub (kompyuterga hech narsa o'rnatmasdan)
1. github.com da bepul akkaunt oching va yangi repozitoriy yarating (masalan `oddiychat`).
2. Shu papkadagi **barcha fayllarni** (yashirin `.github` papkasi bilan) repozitoriyga yuklang.
3. Repozitoriyda **Actions** bo'limiga kiring → "Android APK yig'ish" → **Run workflow**.
4. 5–10 daqiqadan so'ng tugagan ishga kirib, pastdagi **OddiyChat-APK** faylni yuklab oling (zip ichida `app-debug.apk`).
5. APK ni telefonga o'tkazing va o'rnating (Sozlamalar → "Noma'lum manbalardan o'rnatishga ruxsat").

## 2-usul: Android Studio
1. Android Studio o'rnating (JDK 21 u bilan birga keladi).
2. `File → Open` orqali shu papkadagi `android` papkani oching, Gradle sync tugashini kuting.
3. `Build → Build APK(s)` yoki telefonni USB bilan ulab ▶ bosing.

## Veb qismini o'zgartirish
Dastur kodi `www/` papkada (`index.html`, `style.css`, `app.js`). O'zgartirgach:
```
npm install
npx cap sync android
```
so'ng yuqoridagi usullardan biri bilan qayta yig'ing.

## Muhim eslatmalar
- Bu **debug** APK: o'zingiz va tanishlaringiz uchun yetarli. Google Play uchun imzolangan (release) yig'ish kerak.
- Mesh tizimda har bir ishtirokchi hammaga video yuboradi: 5–6 kishidan ko'p bo'lsa telefon qiziydi va sifat pasayadi
  (dastur bunda video bitreytini o'zi kamaytiradi).
- Mobil internet (ba'zi operatorlar)da to'g'ridan-to'g'ri ulanish bo'lmasligi mumkin; PeerJS standart relay (TURN) serveridan foydalanadi.
  Ishonchlilik uchun "Qo'shimcha sozlamalar"da o'z PeerJS serveringizni kiritish mumkin.
- Nickname katta-kichik harfga sezgir; faqat lotin harf, raqam, `_` va `-`.
